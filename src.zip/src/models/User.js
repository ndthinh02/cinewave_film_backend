import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  name:{type:String,trim:true,required:true}, email:{type:String,trim:true,lowercase:true,unique:true,required:true},
  passwordHash:{type:String,required:true}, avatarUrl:{type:String,default:''}, role:{type:String,enum:['user','admin'],default:'user'}
},{timestamps:true});
export default mongoose.model('User',userSchema);
