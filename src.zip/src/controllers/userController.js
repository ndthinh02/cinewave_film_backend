import Favorite from '../models/Favorite.js'; import WatchProgress from '../models/WatchProgress.js';
export async function favorites(req,res){res.json({items:await Favorite.find({userId:req.user.id}).sort({createdAt:-1})});}
export async function addFavorite(req,res){try{const f=await Favorite.findOneAndUpdate({userId:req.user.id,movieSlug:req.body.movieSlug},{$set:{...req.body,userId:req.user.id}},{new:true,upsert:true,setDefaultsOnInsert:true});res.json({item:f});}catch(e){res.status(400).json({message:e.message});}}
export async function removeFavorite(req,res){await Favorite.deleteOne({userId:req.user.id,movieSlug:req.params.slug});res.json({ok:true});}
export async function progressList(req,res){res.json({items:await WatchProgress.find({userId:req.user.id}).sort({lastWatchedAt:-1}).limit(100)});}
export async function saveProgress(req,res){const b=req.body;if(!b.movieSlug)return res.status(400).json({message:'movieSlug là bắt buộc'});const item=await WatchProgress.findOneAndUpdate({userId:req.user.id,movieSlug:b.movieSlug},{$set:{...b,userId:req.user.id,lastWatchedAt:new Date()}},{new:true,upsert:true,setDefaultsOnInsert:true});res.json({item});}
export async function clearHistory(req,res){await WatchProgress.deleteMany({userId:req.user.id});res.json({ok:true});}
